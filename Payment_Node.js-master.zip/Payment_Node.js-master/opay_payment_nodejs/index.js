/**
 * Created by ying.wu on 2017/6/29.
 */
'use strict';

module.exports = require('./lib/opay_payment.js');